### To sync your code:

1. `git fetch --all`
2. `git reset --hard origin/master`
