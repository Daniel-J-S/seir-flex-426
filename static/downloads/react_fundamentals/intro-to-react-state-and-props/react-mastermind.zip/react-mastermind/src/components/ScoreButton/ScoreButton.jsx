import React from 'react';

const ScoreButton = (props) => (
  <button>
    Score Guess
  </button>
);

export default ScoreButton;
