import React from 'react';
import BatteryContainer from './components/BatteryContainer/BatteryContainer';

function App() {
  return (
    <>
      <BatteryContainer />
    </>
  );
}

export default App;
