import React from 'react';

const GuessPeg = (props) => (
  <div>
    {props.color}
  </div>
);

export default GuessPeg;
