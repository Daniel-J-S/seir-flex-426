import React from 'react';
import GuessPeg from '../GuessPeg/GuessPeg';

const GuessPegs = (props) => (
  <div className='flex-h'>
    GuessPegs
    <GuessPeg />
    <GuessPeg />
    <GuessPeg />
    <GuessPeg />
  </div>
);

export default GuessPegs;
