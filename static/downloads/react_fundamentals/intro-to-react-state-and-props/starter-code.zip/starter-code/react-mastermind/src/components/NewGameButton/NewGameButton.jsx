import React from 'react';

const NewGameButton = (props) => (
  <div>
    NewGameButton
  </div>
);

export default NewGameButton;
