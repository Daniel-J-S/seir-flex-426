import React from 'react';

const ColorPicker = (props) => (
  <div>
    ColorPicker
  </div>
);

export default ColorPicker;
