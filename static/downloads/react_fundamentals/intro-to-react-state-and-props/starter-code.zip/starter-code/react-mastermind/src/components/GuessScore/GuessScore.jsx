import React from 'react';

const GuessScore = (props) => (
  <div>
    GuessScore
  </div>
);

export default GuessScore;
