import React from 'react';

const GameTimer = (props) => (
    <div>
        GameTimer
    </div>
);

export default GameTimer;
