import React from 'react';

const GuessPeg = (props) => (
  <div>
    GuessPeg
  </div>
);

export default GuessPeg;
