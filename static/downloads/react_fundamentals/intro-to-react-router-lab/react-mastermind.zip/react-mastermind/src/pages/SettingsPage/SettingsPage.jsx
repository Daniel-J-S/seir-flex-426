import React from 'react';
import { Link } from 'react-router-dom';

const SettingsPage = (props) => {
  return (
    <div>
      <Link to='/'>HOME</Link>
      <h1>Settings Page</h1>
    </div>
  );
};

export default SettingsPage;